import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";
import * as XLSX from "xlsx";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Increase payload limits for image / document base64 upload
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Initialize Gemini SDK with User-Agent header
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is not set in environment variables!");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "dummy-key-for-dev",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// API 1: Parse uploaded document or image using Gemini
app.post("/api/parse-report", async (req, res) => {
  try {
    const { fileName, fileType, fileBase64, textContent, locationHint, monthHint } = req.body;

    let promptContext = "";
    let mediaParts: any[] = [];

    // If Excel file, parse tables first using xlsx library
    if (fileType === "excel" && fileBase64) {
      try {
        const buffer = Buffer.from(fileBase64.split(",")[1] || fileBase64, "base64");
        const workbook = XLSX.read(buffer, { type: "buffer" });
        const sheetNames = workbook.SheetNames;
        let excelText = "";
        sheetNames.forEach((sheetName) => {
          const sheet = workbook.Sheets[sheetName];
          const csv = XLSX.utils.sheet_to_csv(sheet);
          excelText += `\n--- 工作表: ${sheetName} ---\n${csv}\n`;
        });
        promptContext = `[已解析之 Excel 表格內容]:\n${excelText}`;
      } catch (err) {
        console.error("Excel parse error, fallback to text/vision", err);
      }
    }

    if (textContent) {
      promptContext += `\n[文字報告內容]:\n${textContent}`;
    }

    if (fileBase64 && (fileType === "image" || fileType === "pdf")) {
      const mimeType = fileType === "image" 
        ? (fileBase64.startsWith("data:image/png") ? "image/png" : "image/jpeg") 
        : "application/pdf";
      const base64Data = fileBase64.includes(",") ? fileBase64.split(",")[1] : fileBase64;
      
      mediaParts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    }

    const ai = getGeminiClient();

    const systemInstruction = `你是一位專業的商業會議報告分析專家與資料擷取AI。
請從上傳的會議報告（圖片、Excel表格、PDF或文字）中精確擷取以下資訊，並輸出為強型別 JSON 格式：
1. 報告地點（location，例如：松山據點、中山據點、信義據點、站前據點、高雄據點...）。如無法判斷，參考預設地點 ${locationHint || "未知據點"}。
2. 報告月份（month，格式為 YYYY-MM，例如：2026-08、2026-07）。如無法判斷，參考預設月份 ${monthHint || "2026-08"}。
3. 店長/報告人名稱（manager，例如：BAY、ALEX...）。
4. 報告標題（title，例如：松山據點 2026年8月份會議報告）。
5. 數據指標：
   - 來客/流量指標 (trafficMetrics)：包含分店名稱(storeName, 如:一店/總店)、期間(period, 如:2026.8月)、線上詢問數(onlineInquiries)、線上已連絡數(onlineContacts)、轉訪率(conversionRate %)、預約數(appointments)、參觀數(visits)、新入倉數(newSales)、新入倉材積(soldVolume cubft)、退倉數(moveOutCount)、退倉材積(moveOutVolume cubft)。
   - 出租/業績指標 (occupancyMetrics)：包含分店名稱(storeName)、期間(period)、出租率(occupancyRate %)、本月業績(netSales NTD)、目標達成率(targetRate %)、去年同期成長率(yoyGrowth %)。
6. 各店回報事務與討論事項 (issues)：
   - 分類(category): '事務討論' | '修繕設備' | '客戶建議' | '財務刷卡' | '主管營運'
   - 分店(store): 例如 松山三店
   - 描述(description): 詳細問題與現象描述（如漏水、信用卡分期筆數、簡訊通知未收到等）
   - 狀態(status): '待處理' | '處理中' | '已完成'
   - 改善行動方案(actionItem): 具體建議措施
7. 摘要總結 (aiSummary): 100字內簡潔精闢的精華總結。`;

    const promptText = `請分析這份會議報告並回傳結構化資料：
檔案名稱：${fileName || "上傳報告"}
提示地點：${locationHint || "無"}
提示月份：${monthHint || "無"}
${promptContext}`;

    const contentsParts = mediaParts.length > 0 
      ? { parts: [...mediaParts, { text: promptText }] }
      : promptText;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: contentsParts,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            location: { type: Type.STRING },
            month: { type: Type.STRING },
            manager: { type: Type.STRING },
            aiSummary: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            trafficMetrics: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  storeName: { type: Type.STRING },
                  period: { type: Type.STRING },
                  onlineInquiries: { type: Type.NUMBER },
                  onlineContacts: { type: Type.NUMBER },
                  conversionRate: { type: Type.NUMBER },
                  appointments: { type: Type.NUMBER },
                  visits: { type: Type.NUMBER },
                  newSales: { type: Type.NUMBER },
                  soldVolume: { type: Type.NUMBER },
                  moveOutCount: { type: Type.NUMBER },
                  moveOutVolume: { type: Type.NUMBER },
                },
              },
            },
            occupancyMetrics: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  storeName: { type: Type.STRING },
                  period: { type: Type.STRING },
                  occupancyRate: { type: Type.NUMBER },
                  netSales: { type: Type.NUMBER },
                  targetRate: { type: Type.NUMBER },
                  yoyGrowth: { type: Type.NUMBER },
                },
              },
            },
            issues: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  category: { type: Type.STRING },
                  store: { type: Type.STRING },
                  description: { type: Type.STRING },
                  status: { type: Type.STRING },
                  actionItem: { type: Type.STRING },
                  assignedTo: { type: Type.STRING },
                },
              },
            },
          },
        },
      },
    });

    const parsedJson = JSON.parse(response.text || "{}");
    res.json({ success: true, data: parsedJson });
  } catch (error: any) {
    console.error("Error parsing report with Gemini:", error);
    res.status(500).json({ success: false, error: error.message || "Failed to parse report" });
  }
});

// API 2: Comprehensive Multi-Report Cross-Analysis & AI Synthesis
app.post("/api/analyze-reports", async (req, res) => {
  try {
    const { reports, filterInfo } = req.body;

    if (!reports || reports.length === 0) {
      return res.status(400).json({ success: false, error: "No reports provided for analysis" });
    }

    const ai = getGeminiClient();

    const systemInstruction = `你是一位高階營運分析長與營運數據科學家。
你需要針對使用者選取的【多據點/多月份會議報告數據】進行全面的跨據點、跨月份對比綜合彙整分析。

請輸出嚴格的 JSON 格式，包含：
1. executiveSummary (高階執行摘要, 約200-300字，亮點、警訊、整體營運健康度)
2. kpiHighlights (關鍵KPI卡片數據，包含 title, value, trend, type: 'positive' | 'neutral' | 'negative')
3. crossLocationComparison (跨據點與月份的表現對比分析)
4. keyIssuesAndRisks (重要待辦、設備維修、客戶申訴與潛在風險矩陣，含 location, issue, impact, suggestion)
5. recommendations (針對高層營運決策的3-5條具體戰略建議)
6. actionPlan (跨部門與跨據點的具體行動方案清單，包含 id, department, task, priority: '高'|'中'|'低', targetLocation)`;

    const promptText = `以下是篩選條件為 ${JSON.stringify(filterInfo || {})} 的會議報告集合（共 ${reports.length} 份）：

${JSON.stringify(reports, null, 2)}

請進行全面的跨據點與跨月份綜合分析並輸出 JSON 格式。`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            executiveSummary: { type: Type.STRING },
            crossLocationComparison: { type: Type.STRING },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
            kpiHighlights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  value: { type: Type.STRING },
                  trend: { type: Type.STRING },
                  type: { type: Type.STRING },
                },
              },
            },
            keyIssuesAndRisks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  location: { type: Type.STRING },
                  issue: { type: Type.STRING },
                  impact: { type: Type.STRING },
                  suggestion: { type: Type.STRING },
                },
              },
            },
            actionPlan: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  department: { type: Type.STRING },
                  task: { type: Type.STRING },
                  priority: { type: Type.STRING },
                  targetLocation: { type: Type.STRING },
                },
              },
            },
          },
        },
      },
    });

    const analysisResult = JSON.parse(response.text || "{}");
    res.json({ success: true, data: analysisResult });
  } catch (error: any) {
    console.error("Error running AI cross report analysis:", error);
    res.status(500).json({ success: false, error: error.message || "Failed to generate analysis" });
  }
});

// API 3: Interactive Q&A Assistant across meeting reports
app.post("/api/chat", async (req, res) => {
  try {
    const { message, reportsContext, history } = req.body;

    const ai = getGeminiClient();

    const systemInstruction = `你是一位專業且親切的「開會報告數據AI問答助手」。
你的任務是根據使用者目前上傳與選取的會議報告數據（包含各據點的流量、出租率、業績、設備漏水、信用卡分期、簡訊通知等討論事項），給予精準、有條理且具商業價值的解答。

回答原則：
1. 引用資料中的具體數字（如金額、百分比、據點名稱、店長名稱）。
2. 使用 Markdown 格式（粗體、列表、表格、區塊引用）使內容易讀。
3. 態度專業、語氣務實。`;

    const chat = ai.chats.create({
      model: "gemini-3.6-flash",
      config: {
        systemInstruction: `${systemInstruction}\n\n[目前參考的會議報告資料庫]:\n${JSON.stringify(reportsContext || [], null, 2)}`,
      },
    });

    const response = await chat.sendMessage({
      message: message || "請簡述目前的報告狀況",
    });

    res.json({ success: true, answer: response.text });
  } catch (error: any) {
    console.error("Chat error:", error);
    res.status(500).json({ success: false, error: error.message || "Chat processing failed" });
  }
});

// API 4: Generate Executive Report for One-Click Export
app.post("/api/generate-export-report", async (req, res) => {
  try {
    const { reports, filterInfo } = req.body;

    const ai = getGeminiClient();

    const promptText = `請為以下選取的會議報告生成一份正式且精美的【營運會議彙整與分析高階報告】Markdown 內容。
報告應包含：
# 1. 營運總覽與彙整指標
# 2. 各地點（據點）與各月份表現對比 (含數據表格)
# 3. 跨據點議題與改善行動方案 (含修繕、客戶建議、營運待辦)
# 4. 未來營運策略與重點追蹤

請用繁體中文撰寫，語氣專業嚴謹，格式為高品質 Markdown。

篩選條件：${JSON.stringify(filterInfo || {})}
報告資料：${JSON.stringify(reports || [], null, 2)}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: promptText,
    });

    res.json({ success: true, markdown: response.text });
  } catch (error: any) {
    console.error("Export report generation error:", error);
    res.status(500).json({ success: false, error: error.message || "Export generation failed" });
  }
});

async function startServer() {
  // Setup Vite development middleware or static production serving
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
