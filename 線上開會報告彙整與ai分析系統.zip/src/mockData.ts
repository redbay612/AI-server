import { ReportItem } from './types';

export const INITIAL_REPORTS: ReportItem[] = [
  {
    id: 'rep-songshan-202608',
    title: '松山據點 2026年8月份會議報告',
    location: '松山據點',
    month: '2026-08',
    manager: 'BAY',
    uploadDate: '2026-08-05 14:30',
    fileName: '松山據點_2026年8月會議報告.xlsx',
    fileType: 'excel',
    tags: ['松山', '2026-08', '漏水修繕', '信用卡分期', '簡訊通知'],
    trafficMetrics: [
      { storeName: '一店', period: '2026.7月', onlineInquiries: 9, onlineContacts: 8, conversionRate: 89, appointments: 2, visits: 10, newSales: 2, soldVolume: 120, moveOutCount: 0, moveOutVolume: 0 },
      { storeName: '二店', period: '2026.7月', onlineInquiries: 1, onlineContacts: 1, conversionRate: 100, appointments: 1, visits: 2, newSales: 3, soldVolume: 535, moveOutCount: 1, moveOutVolume: 345 },
      { storeName: '三店', period: '2026.7月', onlineInquiries: 0, onlineContacts: 0, conversionRate: 0, appointments: 1, visits: 1, newSales: 0, soldVolume: 0, moveOutCount: 3, moveOutVolume: 630 },
      { storeName: '四店', period: '2026.7月', onlineInquiries: 1, onlineContacts: 1, conversionRate: 100, appointments: 2, visits: 3, newSales: 3, soldVolume: 505, moveOutCount: 7, moveOutVolume: 1640 },
      { storeName: '四A店', period: '2026.7月', onlineInquiries: 0, onlineContacts: 0, conversionRate: 0, appointments: 1, visits: 1, newSales: 2, soldVolume: 160, moveOutCount: 1, moveOutVolume: 75 },
      { storeName: '總店', period: '2026.8月', onlineInquiries: 11, onlineContacts: 10, conversionRate: 91, appointments: 7, visits: 17, newSales: 10, soldVolume: 1320, moveOutCount: 12, moveOutVolume: 2690 },
    ],
    occupancyMetrics: [
      { storeName: '一店', period: '2026.8月', occupancyRate: 99.3, netSales: 365728, targetRate: 96.0, yoyGrowth: 1.35, rentalsCount: 20, cancellationsCount: 5 },
      { storeName: '二店', period: '2026.8月', occupancyRate: 97.1, netSales: 971276, targetRate: 192.0, yoyGrowth: 0.00, rentalsCount: 8, cancellationsCount: 4 },
      { storeName: '三店', period: '2026.8月', occupancyRate: 98.5, netSales: 834402, targetRate: 99.0, yoyGrowth: -0.50, rentalsCount: 28, cancellationsCount: 3 },
      { storeName: '四店', period: '2026.8月', occupancyRate: 97.6, netSales: 182910, targetRate: 52.56, yoyGrowth: -0.81, rentalsCount: 11, cancellationsCount: 3 },
      { storeName: '四A店', period: '2026.8月', occupancyRate: 98.0, netSales: 397128, targetRate: 155.45, yoyGrowth: -2.00, rentalsCount: 2, cancellationsCount: 1 },
      { storeName: '總店', period: '2026.8月', occupancyRate: 98.2, netSales: 2751444, targetRate: 118.01, yoyGrowth: -0.15, rentalsCount: 69, cancellationsCount: 16 },
    ],
    issues: [
      {
        id: 'iss-1',
        category: '修繕設備',
        store: '松山三店',
        description: '三店在6/17及6/25於入口右側走道有漏水發生，目前已將倒灌冷氣水引流，需再觀察；尚有一個漏水點沒抓到，管道包在艙位內部，增加施作困難。',
        status: '處理中',
        actionItem: '聯絡水電工程師於非營運尖峰拆卸艙位側板進行壁內管道探測。',
        assignedTo: '工程部 BAY',
      },
      {
        id: 'iss-2',
        category: '財務刷卡',
        store: '松山總店',
        description: '信用卡刷卡分期統計：中國信託12期10筆；國泰世華3期1筆。分期交易比例較上期增加15%。',
        status: '已完成',
        actionItem: '與中國信託確認零利率分期手續費優惠專案續約。',
        assignedTo: '財務部',
      },
      {
        id: 'iss-3',
        category: '客戶建議',
        store: '松山各店',
        description: '最近幾個月客人陸續反映沒收到繳費提醒簡訊，經查為電信業者將大量系統簡訊歸類為垃圾簡訊。',
        status: '處理中',
        actionItem: '於後台系統同步開啟LINE官方帳號訊息推播通知，並貼出門市海報引導客戶綁定。',
        assignedTo: '資訊客服組',
      }
    ],
    aiSummary: '松山據點8月份總業績達 $2,751,444（目標達成率118.01%），整體出租率保持在 98.2% 的高水平。主要關注項目為三店入口走道漏水問題施作困難，以及客戶簡訊通知漏收情事。'
  },
  {
    id: 'rep-zhongshan-202608',
    title: '中山據點 2026年8月份會議報告',
    location: '中山據點',
    month: '2026-08',
    manager: 'ALEX',
    uploadDate: '2026-08-04 10:15',
    fileName: '中山據點_2026年8月報告.pdf',
    fileType: 'pdf',
    tags: ['中山', '2026-08', '電梯保養', '線上推廣'],
    trafficMetrics: [
      { storeName: '中山一店', period: '2026.8月', onlineInquiries: 18, onlineContacts: 15, conversionRate: 83, appointments: 8, visits: 12, newSales: 6, soldVolume: 850, moveOutCount: 2, moveOutVolume: 210 },
      { storeName: '中山二店', period: '2026.8月', onlineInquiries: 12, onlineContacts: 10, conversionRate: 83, appointments: 5, visits: 9, newSales: 4, soldVolume: 620, moveOutCount: 1, moveOutVolume: 120 },
      { storeName: '總店', period: '2026.8月', onlineInquiries: 30, onlineContacts: 25, conversionRate: 83, appointments: 13, visits: 21, newSales: 10, soldVolume: 1470, moveOutCount: 3, moveOutVolume: 330 },
    ],
    occupancyMetrics: [
      { storeName: '中山一店', period: '2026.8月', occupancyRate: 96.5, netSales: 1420000, targetRate: 105.2, yoyGrowth: 3.20, rentalsCount: 18, cancellationsCount: 4 },
      { storeName: '中山二店', period: '2026.8月', occupancyRate: 94.8, netSales: 1180000, targetRate: 98.0, yoyGrowth: 1.50, rentalsCount: 12, cancellationsCount: 2 },
      { storeName: '總店', period: '2026.8月', occupancyRate: 95.7, netSales: 2600000, targetRate: 101.8, yoyGrowth: 2.40, rentalsCount: 30, cancellationsCount: 6 },
    ],
    issues: [
      {
        id: 'iss-201',
        category: '修繕設備',
        store: '中山一店',
        description: '貨梯煞車皮磨損發出異音，已預約鋼索與電梯安全檢驗團隊進行例行大保養。',
        status: '處理中',
        actionItem: '8/12 離峰時段全天封閉電梯檢修，提前三天通知客戶。',
        assignedTo: '管理組 ALEX',
      },
      {
        id: 'iss-202',
        category: '事務討論',
        store: '中山據點',
        description: '針對學生搬家季推出中型倉體85折優惠，線上廣告轉換率提升12%。',
        status: '已完成',
        actionItem: '繼續沿用FB/IG精準地緣廣告投放。',
        assignedTo: '行銷部',
      }
    ],
    aiSummary: '中山據點8月業績達標率101.8%，出租率95.7%。貨梯預防性維修進行中，學生季活動帶動短租需求上升。'
  },
  {
    id: 'rep-xinyi-202608',
    title: '信義據點 2026年8月份會議報告',
    location: '信義據點',
    month: '2026-08',
    manager: 'CAROL',
    uploadDate: '2026-08-06 16:00',
    fileName: '信義據點_2026年8月會議報告.docx',
    fileType: 'word',
    tags: ['信義', '2026-08', '溫濕度控管', '高價物藏'],
    trafficMetrics: [
      { storeName: '信義旗艦店', period: '2026.8月', onlineInquiries: 22, onlineContacts: 20, conversionRate: 91, appointments: 10, visits: 18, newSales: 9, soldVolume: 1680, moveOutCount: 1, moveOutVolume: 150 },
    ],
    occupancyMetrics: [
      { storeName: '信義旗艦店', period: '2026.8月', occupancyRate: 99.1, netSales: 3120000, targetRate: 112.5, yoyGrowth: 4.80, rentalsCount: 24, cancellationsCount: 3 },
    ],
    issues: [
      {
        id: 'iss-301',
        category: '修繕設備',
        store: '信義旗艦店',
        description: 'B區除濕機水箱滿水感應器故障，導致警報器誤報兩次，需更換感測模組。',
        status: '待處理',
        actionItem: '聯繫原廠採購新感測器並改為自動排水管路。',
        assignedTo: '設備組',
      }
    ],
    aiSummary: '信義據點出租率高達 99.1%，業績達成率112.5%為全公司第二。急需解決B區除濕機排水連線問題。'
  },
  {
    id: 'rep-songshan-202607',
    title: '松山據點 2026年7月份會議報告',
    location: '松山據點',
    month: '2026-07',
    manager: 'BAY',
    uploadDate: '2026-07-04 11:20',
    fileName: '松山據點_2026年7月報告.xlsx',
    fileType: 'excel',
    tags: ['松山', '2026-07', '歷史紀錄'],
    trafficMetrics: [
      { storeName: '總店', period: '2026.7月', onlineInquiries: 16, onlineContacts: 14, conversionRate: 88, appointments: 6, visits: 14, newSales: 10, soldVolume: 1075, moveOutCount: 5, moveOutVolume: 630 },
    ],
    occupancyMetrics: [
      { storeName: '總店', period: '2026.7月', occupancyRate: 98.3, netSales: 1623294, targetRate: 69.62, yoyGrowth: 0.76, rentalsCount: 64, cancellationsCount: 22 },
    ],
    issues: [
      {
        id: 'iss-101',
        category: '修繕設備',
        store: '松山三店',
        description: '三店冷氣水倒灌走道，暫時使用引流接水管處置。',
        status: '處理中',
        actionItem: '持續追蹤管道與冷氣主機保養。',
        assignedTo: 'BAY',
      }
    ],
    aiSummary: '松山據點7月業績為 $1,623,294，8月份月增幅度高達69.5%，營運大幅回升。'
  },
  {
    id: 'rep-kaohsiung-202608',
    title: '高雄據點 2026年8月份會議報告',
    location: '高雄據點',
    month: '2026-08',
    manager: 'DAVID',
    uploadDate: '2026-08-03 09:40',
    fileName: '高雄據點_202608.pdf',
    fileType: 'pdf',
    tags: ['高雄', '2026-08', '南區門市', '磁卡感應'],
    trafficMetrics: [
      { storeName: '高雄巨蛋店', period: '2026.8月', onlineInquiries: 14, onlineContacts: 12, conversionRate: 85, appointments: 5, visits: 11, newSales: 5, soldVolume: 790, moveOutCount: 2, moveOutVolume: 200 },
    ],
    occupancyMetrics: [
      { storeName: '高雄巨蛋店', period: '2026.8月', occupancyRate: 92.4, netSales: 1250000, targetRate: 93.5, yoyGrowth: 5.10, rentalsCount: 11, cancellationsCount: 3 },
    ],
    issues: [
      {
        id: 'iss-401',
        category: '主管營運',
        store: '高雄巨蛋店',
        description: '門禁門鎖主機感應器老化，部分客戶門禁卡需刷2-3次才能解除保全。',
        status: '待處理',
        actionItem: '申請採購新世代藍芽/門禁二合一讀卡機。',
        assignedTo: '資訊組',
      }
    ],
    aiSummary: '高雄據點8月出租率92.4%，年增率顯著進步5.1%，門禁設備升級申請中。'
  }
];
