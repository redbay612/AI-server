import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  Calendar, 
  Plus, 
  Sparkles, 
  Download, 
  FileSpreadsheet, 
  AlertTriangle, 
  TrendingUp, 
  Layers, 
  BarChart3, 
  CheckCircle2,
  FolderTree,
  ArrowRight,
  Bot
} from 'lucide-react';

import { ReportItem, FilterState } from './types';
import { INITIAL_REPORTS } from './mockData';
import { Navbar } from './components/Navbar';
import { FilterBar } from './components/FilterBar';
import { ReportCard } from './components/ReportCard';
import { UploadModal } from './components/UploadModal';
import { ReportDetailModal } from './components/ReportDetailModal';
import { AIAnalysisDashboard } from './components/AIAnalysisDashboard';
import { AIChatDrawer } from './components/AIChatDrawer';
import { ExportModal } from './components/ExportModal';
import { MatrixView } from './components/MatrixView';
import { TableView } from './components/TableView';

const STORAGE_KEY = 'meeting_reports_data_v2';

export default function App() {
  // Load reports from local storage or fallback to mock data
  const [reports, setReports] = useState<ReportItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to parse local storage reports', e);
    }
    return INITIAL_REPORTS;
  });

  // Save to local storage on report change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch (e) {
      console.error('Failed to save reports to local storage', e);
    }
  }, [reports]);

  // Filter state
  const [filters, setFilters] = useState<FilterState>({
    selectedLocation: 'ALL',
    selectedMonth: 'ALL',
    searchQuery: '',
    selectedCategory: undefined,
  });

  // View Mode: 'grid' | 'matrix' | 'table'
  const [viewMode, setViewMode] = useState<'grid' | 'matrix' | 'table'>('grid');

  // Modals & Drawers
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [selectedReportForDetail, setSelectedReportForDetail] = useState<ReportItem | null>(null);
  const [isAIAnalysisOpen, setIsAIAnalysisOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);

  // Extract unique locations and months dynamically
  const uniqueLocations = useMemo(() => {
    const locs = new Set<string>();
    reports.forEach((r) => locs.add(r.location));
    // Default standard branches if not present
    ['松山據點', '中山據點', '信義據點', '站前據點', '高雄據點'].forEach((l) => locs.add(l));
    return Array.from(locs);
  }, [reports]);

  const uniqueMonths = useMemo(() => {
    const mset = new Set<string>();
    reports.forEach((r) => mset.add(r.month));
    ['2026-08', '2026-07', '2026-06'].forEach((m) => mset.add(m));
    return Array.from(mset).sort().reverse();
  }, [reports]);

  const categories = useMemo(() => {
    return ['事務討論', '修繕設備', '客戶建議', '財務刷卡', '主管營運'];
  }, []);

  // Filter reports
  const filteredReports = useMemo(() => {
    return reports.filter((rep) => {
      // 1. Location filter
      if (filters.selectedLocation !== 'ALL' && rep.location !== filters.selectedLocation) {
        return false;
      }
      // 2. Month filter
      if (filters.selectedMonth !== 'ALL' && rep.month !== filters.selectedMonth) {
        return false;
      }
      // 3. Category filter
      if (filters.selectedCategory) {
        const hasMatchingIssue = rep.issues.some((i) => i.category === filters.selectedCategory);
        if (!hasMatchingIssue) return false;
      }
      // 4. Keyword search
      if (filters.searchQuery.trim() !== '') {
        const q = filters.searchQuery.toLowerCase();
        const matchesTitle = rep.title.toLowerCase().includes(q);
        const matchesManager = rep.manager.toLowerCase().includes(q);
        const matchesLocation = rep.location.toLowerCase().includes(q);
        const matchesMonth = rep.month.includes(q);
        const matchesTags = rep.tags.some((t) => t.toLowerCase().includes(q));
        const matchesIssues = rep.issues.some(
          (i) => i.description.toLowerCase().includes(q) || (i.actionItem && i.actionItem.toLowerCase().includes(q))
        );

        if (!matchesTitle && !matchesManager && !matchesLocation && !matchesMonth && !matchesTags && !matchesIssues) {
          return false;
        }
      }

      return true;
    });
  }, [reports, filters]);

  // Total summary statistics across filtered reports
  const totalNetSales = useMemo(() => {
    return filteredReports.reduce((acc, rep) => {
      const repTotal = rep.occupancyMetrics.reduce((sum, m) => sum + (m.netSales || 0), 0);
      return acc + repTotal;
    }, 0);
  }, [filteredReports]);

  const overallAvgOccupancy = useMemo(() => {
    let count = 0;
    let sum = 0;
    filteredReports.forEach((rep) => {
      rep.occupancyMetrics.forEach((m) => {
        if (m.occupancyRate) {
          sum += m.occupancyRate;
          count++;
        }
      });
    });
    return count > 0 ? (sum / count).toFixed(1) : '—';
  }, [filteredReports]);

  const totalPendingIssues = useMemo(() => {
    return filteredReports.reduce((acc, rep) => {
      return acc + rep.issues.filter((i) => i.status !== '已完成').length;
    }, 0);
  }, [filteredReports]);

  // Location distribution calculation for Bento card
  const locationDistribution = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredReports.forEach((r) => {
      counts[r.location] = (counts[r.location] || 0) + 1;
    });
    const total = filteredReports.length || 1;
    return Object.entries(counts)
      .map(([name, count]) => ({
        name,
        count,
        percentage: Math.round((count / total) * 100),
      }))
      .sort((a, b) => b.count - a.count);
  }, [filteredReports]);

  // Handlers
  const handleAddReport = (newReport: ReportItem) => {
    setReports((prev) => [newReport, ...prev]);
  };

  const handleDeleteReport = (id: string) => {
    if (confirm('確定要刪除這份會議報告嗎？')) {
      setReports((prev) => prev.filter((r) => r.id !== id));
    }
  };

  const handleResetData = () => {
    if (confirm('確定要將報告重設為初始範例資料嗎？（這將涵蓋松山、中山、信義等據點）')) {
      setReports(INITIAL_REPORTS);
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const filterContextText = `地點: ${filters.selectedLocation === 'ALL' ? '全部據點' : filters.selectedLocation}, 月份: ${filters.selectedMonth === 'ALL' ? '跨月份' : filters.selectedMonth}, 關鍵字: ${filters.searchQuery || '無'}`;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-500 selection:text-white pb-12">
      {/* Top Navbar */}
      <Navbar
        reportCount={reports.length}
        filteredCount={filteredReports.length}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenAIAnalysis={() => setIsAIAnalysisOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onToggleChat={() => setIsChatOpen((prev) => !prev)}
        isChatOpen={isChatOpen}
        onResetData={handleResetData}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Main Bento Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Bento Card 1: AI Core Summary Card (2 cols) */}
          <div className="md:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between transition-all hover:shadow-md">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center font-bold">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                  </div>
                  <h3 className="font-bold text-slate-800 text-sm">AI 核心營運與跨區洞察</h3>
                </div>
                <button 
                  onClick={() => setIsAIAnalysisOpen(true)}
                  className="text-xs text-purple-600 hover:text-purple-800 font-bold flex items-center gap-1 bg-purple-50 hover:bg-purple-100 px-2.5 py-1 rounded-lg border border-purple-100 transition-colors"
                >
                  <span>簡報深度分析</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
                本月會議重點集中在各據點出租率優化與修繕即時回報。AI 跨數據分析顯示，全區已有 <strong className="text-slate-900">{filteredReports.length} 份</strong> 報告建檔，平均出租率達到 <strong className="text-blue-600">{overallAvgOccupancy}%</strong>，總業績累積達 <strong className="text-emerald-600">NT$ {totalNetSales.toLocaleString()}</strong>。
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t border-slate-100">
              <span className="px-2.5 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-md uppercase tracking-wider">業績穩健</span>
              <span className="px-2.5 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold rounded-md uppercase tracking-wider">出租率指標</span>
              <span className="px-2.5 py-1 bg-amber-50 text-amber-600 text-[10px] font-bold rounded-md uppercase tracking-wider">修繕與設備列管 ({totalPendingIssues}項)</span>
            </div>
          </div>

          {/* Bento Card 2: File Stats Card (Dark Theme) */}
          <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-md flex flex-col justify-between border border-slate-800 transition-all hover:shadow-lg">
            <div>
              <p className="text-slate-400 text-[11px] font-bold uppercase tracking-wider mb-1">已彙整會議報告</p>
              <h2 className="text-4xl font-light tracking-tight">{filteredReports.length} <span className="text-base text-slate-400 font-normal">份</span></h2>
              <p className="text-[11px] text-slate-400 mt-1">來自 {uniqueLocations.length} 個營運據點</p>
            </div>
            <div className="h-10 w-full flex items-end gap-1.5 mt-3">
              <div className="bg-blue-500 rounded-t w-full h-[40%] animate-pulse"></div>
              <div className="bg-blue-500 rounded-t w-full h-[65%]"></div>
              <div className="bg-blue-500 rounded-t w-full h-[35%]"></div>
              <div className="bg-blue-400 rounded-t w-full h-[90%]"></div>
              <div className="bg-blue-500 rounded-t w-full h-[55%]"></div>
              <div className="bg-indigo-400 rounded-t w-full h-[75%]"></div>
            </div>
          </div>

          {/* Bento Card 3: Quick Export Card (Blue Accent) */}
          <div 
            onClick={() => setIsExportOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white p-5 rounded-2xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer group transition-all transform hover:-translate-y-0.5"
          >
            <div className="mb-3 p-3 bg-blue-500/80 rounded-full group-hover:scale-110 transition-transform shadow-xs">
              <Download className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-sm mb-1">一鍵導出報告</h3>
            <p className="text-blue-100 text-xs px-2 opacity-90">自動彙整圖表與分析結果至 Excel / PDF</p>
          </div>

          {/* Bento Card 4: Location Distribution (Emerald Card) */}
          <div className="bg-emerald-50/90 p-5 rounded-2xl border border-emerald-100 shadow-xs flex flex-col justify-between">
            <h3 className="font-bold text-emerald-900 text-xs uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>據點分布頻率</span>
              <span className="text-[10px] text-emerald-700 font-normal">依報告量排序</span>
            </h3>
            <div className="space-y-2.5">
              {locationDistribution.slice(0, 3).map((item) => (
                <div key={item.name}>
                  <div className="flex justify-between text-[11px] font-bold text-emerald-800 mb-1">
                    <span>{item.name}</span>
                    <span>{item.percentage}%</span>
                  </div>
                  <div className="w-full bg-emerald-200/60 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-600 h-full rounded-full transition-all duration-500" style={{ width: `${item.percentage}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bento Card 5: AI Meeting Mood & Health Score Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col items-center justify-center text-center">
            <h3 className="font-bold text-slate-700 text-xs mb-2">AI 會議氛圍與營運健康度</h3>
            <div className="w-20 h-20 rounded-full border-8 border-emerald-400 border-t-slate-100 flex items-center justify-center relative my-1 shadow-xs">
              <span className="text-xl font-black text-slate-800">88</span>
              <span className="absolute -bottom-2 bg-emerald-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow-xs">積極</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-3 italic line-clamp-2">"跨據點團隊溝通順暢，聚焦於建設性改善方案"</p>
          </div>

          {/* Bento Card 6: AI Chat Banner Card (2 cols) */}
          <div 
            onClick={() => setIsChatOpen(true)}
            className="md:col-span-2 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-2xl shadow-md border border-slate-800 flex items-center justify-between cursor-pointer group hover:border-indigo-500/50 transition-all"
          >
            <div className="flex items-center space-x-3.5">
              <div className="p-3 bg-amber-500/20 text-amber-300 rounded-xl border border-amber-500/30 group-hover:scale-105 transition-transform shrink-0">
                <Bot className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-white">智慧會議報告 AI 對話問答</h3>
                  <span className="bg-amber-400/20 text-amber-300 text-[10px] px-2 py-0.5 rounded-full font-bold">隨時提問</span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">點擊詢問特定門市出租率、設備修繕細節或跨區數據比較</p>
              </div>
            </div>
            <div className="px-3.5 py-1.5 bg-slate-800 group-hover:bg-amber-500 group-hover:text-slate-950 text-amber-300 rounded-xl text-xs font-bold transition-colors shrink-0">
              開啟 AI 助手
            </div>
          </div>

        </div>

        {/* Categorization & Search Filter Bar */}
        <FilterBar
          locations={uniqueLocations}
          months={uniqueMonths}
          categories={categories}
          filters={filters}
          onFilterChange={setFilters}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          totalFiltered={filteredReports.length}
        />

        {/* Content View Modes */}
        {filteredReports.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center space-y-4">
            <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
              <FolderTree className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">找不到符合地點或月份條件的會議報告</h3>
              <p className="text-xs text-slate-400 mt-1">請嘗試調整篩選條件，或上傳新的會議報告</p>
            </div>
            <button
              onClick={() => setIsUploadOpen(true)}
              className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl text-xs shadow-md"
            >
              + 上傳新報告
            </button>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredReports.map((report) => (
              <ReportCard
                key={report.id}
                report={report}
                onSelect={setSelectedReportForDetail}
                onDelete={handleDeleteReport}
                onSingleAIAnalyze={(rep) => setSelectedReportForDetail(rep)}
              />
            ))}
          </div>
        ) : viewMode === 'matrix' ? (
          <MatrixView
            reports={filteredReports}
            locations={uniqueLocations}
            months={uniqueMonths}
            onSelectReport={setSelectedReportForDetail}
          />
        ) : (
          <TableView
            reports={filteredReports}
            onSelectReport={setSelectedReportForDetail}
          />
        )}
      </main>

      {/* Modals & Drawers */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onAddReport={handleAddReport}
        locations={uniqueLocations}
      />

      <ReportDetailModal
        report={selectedReportForDetail}
        onClose={() => setSelectedReportForDetail(null)}
        onSingleAIAnalyze={(rep) => {
          setSelectedReportForDetail(null);
          setIsAIAnalysisOpen(true);
        }}
      />

      <AIAnalysisDashboard
        isOpen={isAIAnalysisOpen}
        onClose={() => setIsAIAnalysisOpen(false)}
        reports={filteredReports}
        filterContextText={filterContextText}
        onOpenExport={() => {
          setIsAIAnalysisOpen(false);
          setIsExportOpen(true);
        }}
      />

      <AIChatDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        reports={filteredReports}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        reports={filteredReports}
        filterInfo={filterContextText}
      />
    </div>
  );
}
