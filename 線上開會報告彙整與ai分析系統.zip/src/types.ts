export type FileType = 'excel' | 'pdf' | 'image' | 'word' | 'manual';

export interface TrafficMetric {
  storeName: string;
  period: string; // e.g. "2026-08" or "2026.8月"
  onlineInquiries?: number;
  onlineContacts?: number;
  conversionRate?: number; // e.g. 89%
  appointments?: number;
  visits?: number;
  newSales?: number;
  soldVolume?: number; // cubft
  moveOutCount?: number;
  moveOutVolume?: number; // cubft
}

export interface OccupancyMetric {
  storeName: string;
  period: string;
  occupancyRate: number; // e.g. 98.2
  netSales: number; // NTD
  targetRate: number; // e.g. 118%
  yoyGrowth: number; // e.g. 2.03%
  rentalsCount?: number;
  cancellationsCount?: number;
}

export interface StoreIssue {
  id: string;
  category: '事務討論' | '修繕設備' | '客戶建議' | '財務刷卡' | '主管營運';
  store: string;
  description: string;
  status: '待處理' | '處理中' | '已完成';
  actionItem?: string;
  assignedTo?: string;
}

export interface ReportItem {
  id: string;
  title: string;
  location: string; // 地點 e.g. "松山據點", "中山據點", "信義據點", "站前據點", "高雄據點"
  month: string; // 月份 e.g. "2026-08", "2026-07"
  manager: string;
  uploadDate: string;
  fileName: string;
  fileType: FileType;
  rawText?: string;
  fileDataUrl?: string; // image or file preview if available
  trafficMetrics: TrafficMetric[];
  occupancyMetrics: OccupancyMetric[];
  issues: StoreIssue[];
  aiSummary?: string;
  tags: string[];
}

export interface AIAnalysisResult {
  executiveSummary: string;
  kpiHighlights: {
    title: string;
    value: string;
    trend: string;
    type: 'positive' | 'neutral' | 'negative';
  }[];
  crossLocationComparison: string;
  keyIssuesAndRisks: {
    location: string;
    issue: string;
    impact: string;
    suggestion: string;
  }[];
  recommendations: string[];
  actionPlan: {
    id: string;
    department: string;
    task: string;
    priority: '高' | '中' | '低';
    targetLocation: string;
  }[];
}

export interface FilterState {
  selectedLocation: string; // 'ALL' or specific
  selectedMonth: string; // 'ALL' or specific
  searchQuery: string;
  selectedCategory?: string;
}
