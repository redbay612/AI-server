import React, { useState } from 'react';
import { 
  X, 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  Loader2, 
  FileText,
  HelpCircle
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ReportItem } from '../types';

interface AIChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  reports: ReportItem[];
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  time: string;
}

export const AIChatDrawer: React.FC<AIChatDrawerProps> = ({
  isOpen,
  onClose,
  reports,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-welcome',
      sender: 'ai',
      text: `你好！我是開會報告數據 AI 助手。我已同步載入目前系統中的 **${reports.length} 份會議報告數據**。您可以向我詢問任何跨據點出租率、設備修繕問題（如漏水）、業績比較或顧客反饋等細節！`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const prompt = textToSend || input;
    if (!prompt.trim() || isSending) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: prompt,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsSending(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          reportsContext: reports,
        }),
      });

      const data = await response.json();
      if (data.success && data.answer) {
        const aiMsg: Message = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: data.answer,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, aiMsg]);
      } else {
        throw new Error(data.error || '無法取得回答');
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        text: '抱歉，處理您的問題時發生錯誤，請稍後再試。',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSending(false);
    }
  };

  const sampleQuestions = [
    '哪些據點有漏水或設備故障需要維修？',
    '幫我比較各據點8月份的出租率與業績達成率',
    '客人在簡訊與通知方面有什麼常見問題與解決方案？',
    '摘要松山據點與中山據點的主要經營重點',
  ];

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[450px] bg-white shadow-2xl border-l border-slate-200 flex flex-col">
      {/* Header */}
      <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <div className="p-2 bg-amber-500/20 text-amber-300 rounded-xl border border-amber-500/30">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">智慧報告問答助手</h3>
            <p className="text-[11px] text-slate-400">連線至 Gemini 3.6 Flash • {reports.length} 份報告在快取中</p>
          </div>
        </div>

        <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Quick Suggested Prompt Pills */}
      <div className="p-3 bg-slate-50 border-b border-slate-200/80 space-y-1.5">
        <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
          <HelpCircle className="w-3.5 h-3.5 text-indigo-500" />
          <span>快速提問範例:</span>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] no-scrollbar">
          {sampleQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              disabled={isSending}
              className="px-2.5 py-1 bg-white hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 rounded-lg border border-slate-200 shrink-0 font-medium transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages */}
      <div className="p-4 flex-1 overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start space-x-2.5 ${msg.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}
          >
            <div className={`p-2 rounded-xl text-white shrink-0 ${
              msg.sender === 'user' ? 'bg-blue-600' : 'bg-slate-800'
            }`}>
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-amber-400" />}
            </div>

            <div className={`max-w-[82%] p-3.5 rounded-2xl text-xs space-y-1 shadow-2xs ${
              msg.sender === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200/80'
            }`}>
              <div className="markdown-body prose prose-xs max-w-none text-xs leading-relaxed">
                <ReactMarkdown>{msg.text}</ReactMarkdown>
              </div>
              <span className={`text-[9px] block text-right mt-1 ${
                msg.sender === 'user' ? 'text-blue-200' : 'text-slate-400'
              }`}>
                {msg.time}
              </span>
            </div>
          </div>
        ))}

        {isSending && (
          <div className="flex items-center space-x-2 text-xs text-slate-400 bg-slate-50 p-3 rounded-xl border border-slate-200 w-fit">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
            <span>AI 正在檢索會議報告數據並生成回答...</span>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-3 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-2"
        >
          <input
            type="text"
            placeholder="請輸入任何關於會議報告的問題..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isSending}
            className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={!input.trim() || isSending}
            className="p-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-xl shadow-sm transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
