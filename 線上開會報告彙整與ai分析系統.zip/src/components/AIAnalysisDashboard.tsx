import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Loader2, 
  X, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  Building2, 
  FileText, 
  Download, 
  ListChecks,
  BarChart2,
  PieChart as PieChartIcon,
  Lightbulb
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  AreaChart, 
  Area 
} from 'recharts';
import ReactMarkdown from 'react-markdown';
import { ReportItem, AIAnalysisResult } from '../types';

interface AIAnalysisDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  reports: ReportItem[];
  filterContextText: string;
  onOpenExport: () => void;
}

export const AIAnalysisDashboard: React.FC<AIAnalysisDashboardProps> = ({
  isOpen,
  onClose,
  reports,
  filterContextText,
  onOpenExport,
}) => {
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && reports.length > 0) {
      runAnalysis();
    }
  }, [isOpen, reports]);

  const runAnalysis = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/analyze-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reports,
          filterInfo: filterContextText,
        }),
      });

      const result = await response.json();
      if (result.success && result.data) {
        setAnalysis(result.data);
      } else {
        throw new Error(result.error || '分析產生失敗');
      }
    } catch (err: any) {
      console.error('AI Analysis Error:', err);
      setError(err.message || 'Gemini 智慧分析時發生錯誤，請稍後重試');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  // Prepare chart data for Recharts visualization
  const chartDataByLocation = reports.map((rep) => {
    const totalSales = rep.occupancyMetrics.reduce((sum, m) => sum + (m.netSales || 0), 0);
    const avgOcc = rep.occupancyMetrics.length > 0
      ? (rep.occupancyMetrics.reduce((sum, m) => sum + (m.occupancyRate || 0), 0) / rep.occupancyMetrics.length)
      : 0;
    const avgConv = rep.trafficMetrics.length > 0
      ? (rep.trafficMetrics.reduce((sum, m) => sum + (m.conversionRate || 0), 0) / rep.trafficMetrics.length)
      : 0;

    return {
      name: `${rep.location} (${rep.month.slice(5)}月)`,
      totalSales: Math.round(totalSales / 10000), // In 10,000 NTD for display
      occupancyRate: Number(avgOcc.toFixed(1)),
      conversionRate: Number(avgConv.toFixed(1)),
      issuesCount: rep.issues.length,
    };
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-50 rounded-2xl max-w-5xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-gradient-to-tr from-amber-500 to-indigo-500 rounded-xl shadow-inner text-slate-950">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-black text-white">Gemini 跨報告智慧分析與整合簡報</h2>
                <span className="bg-amber-400/20 text-amber-300 text-xs px-2.5 py-0.5 rounded-full border border-amber-400/30 font-bold">
                  跨據點 • 跨月份
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                已針對 <strong className="text-white">{reports.length}</strong> 份會議報告進行跨區綜合數據建模與風險掃描 ({filterContextText})
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={runAnalysis}
              disabled={isLoading}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-xl text-xs font-semibold border border-slate-700 flex items-center space-x-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>重新分析</span>
            </button>

            <button
              onClick={onOpenExport}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1 shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>匯出簡報</span>
            </button>

            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {isLoading ? (
            <div className="py-20 flex flex-col items-center justify-center space-y-4 text-slate-600">
              <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
              <div className="text-center">
                <p className="text-sm font-bold text-slate-800">Gemini 正在全速進行跨據點數據對比與風險分析...</p>
                <p className="text-xs text-slate-400 mt-1">深度掃描各門市業績達成率、出租率趨勢、設備修繕與客戶爭議焦點</p>
              </div>
            </div>
          ) : error ? (
            <div className="p-6 bg-red-50 border border-red-200 rounded-2xl text-center space-y-3">
              <AlertTriangle className="w-8 h-8 text-red-500 mx-auto" />
              <p className="text-sm font-bold text-red-800">{error}</p>
              <button
                onClick={runAnalysis}
                className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold"
              >
                重試分析
              </button>
            </div>
          ) : analysis ? (
            <>
              {/* Executive Summary Card */}
              <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm space-y-2">
                <h3 className="text-sm font-bold text-indigo-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  高階營運總覽與健康度判讀 (Executive Summary)
                </h3>
                <div className="text-xs text-slate-700 leading-relaxed font-medium bg-indigo-50/40 p-4 rounded-xl border border-indigo-100">
                  <p>{analysis.executiveSummary}</p>
                </div>
              </div>

              {/* KPI Highlights Grid */}
              {analysis.kpiHighlights && analysis.kpiHighlights.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {analysis.kpiHighlights.map((item, idx) => (
                    <div key={idx} className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs space-y-1">
                      <span className="text-slate-400 text-[11px] font-medium block">{item.title}</span>
                      <div className="text-lg font-black text-slate-900">{item.value}</div>
                      <div className={`text-[11px] font-bold flex items-center gap-1 ${
                        item.type === 'positive' ? 'text-emerald-600' : item.type === 'negative' ? 'text-red-500' : 'text-slate-500'
                      }`}>
                        <TrendingUp className="w-3 h-3" />
                        <span>{item.trend}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Visual Recharts Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Chart 1: Occupancy Rate vs Conversion Rate by Location */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                    <BarChart2 className="w-4 h-4 text-blue-600" />
                    各據點平均出租率 (%) 與 訪客轉換率 (%) 對比
                  </h4>
                  <div className="h-64 w-full text-xs">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartDataByLocation}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                        <YAxis stroke="#64748b" tick={{ fontSize: 11 }} domain={[0, 100]} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="occupancyRate" name="出租率 (%)" fill="#2563eb" radius={[6, 6, 0, 0]} />
                        <Bar dataKey="conversionRate" name="轉訪率 (%)" fill="#6366f1" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Chart 2: Total Sales (10k NTD) */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                    <PieChartIcon className="w-4 h-4 text-emerald-600" />
                    各據點總業績規模 (單位: 萬元 NTD)
                  </h4>
                  <div className="h-64 w-full text-xs">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartDataByLocation}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                        <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                        <Tooltip />
                        <Area type="monotone" dataKey="totalSales" name="總業績(萬元)" stroke="#10b981" fill="#d1fae5" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Cross Location Comparison Section */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs space-y-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-indigo-600" />
                  跨地區與各據點特質與表現對比
                </h3>
                <div className="text-xs text-slate-700 leading-relaxed font-medium bg-slate-50 p-4 rounded-xl border border-slate-200/60">
                  <p className="whitespace-pre-wrap">{analysis.crossLocationComparison}</p>
                </div>
              </div>

              {/* Key Issues & Risk Matrix */}
              {analysis.keyIssuesAndRisks && analysis.keyIssuesAndRisks.length > 0 && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    重點設備故障、客戶申訴與跨區風險警訊矩陣
                  </h3>

                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px]">
                        <tr>
                          <th className="p-3">歸屬據點</th>
                          <th className="p-3">事件與問題描述</th>
                          <th className="p-3">營運影響與風險</th>
                          <th className="p-3">AI 改善對策與建議</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {analysis.keyIssuesAndRisks.map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="p-3 font-bold text-slate-800 shrink-0">{row.location}</td>
                            <td className="p-3 font-medium text-slate-800">{row.issue}</td>
                            <td className="p-3 text-red-600 font-medium">{row.impact}</td>
                            <td className="p-3 text-indigo-900 bg-indigo-50/30 rounded-lg">{row.suggestion}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Action Plan Checklist */}
              {analysis.actionPlan && analysis.actionPlan.length > 0 && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <ListChecks className="w-4 h-4 text-emerald-600" />
                    跨部門與跨據點改善行動方案任務清單
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {analysis.actionPlan.map((act, idx) => (
                      <div key={idx} className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="bg-slate-800 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                            {act.department}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            act.priority === '高' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            優先級: {act.priority}
                          </span>
                        </div>
                        <p className="font-bold text-slate-800">{act.task}</p>
                        <p className="text-[11px] text-slate-400">目標據點: {act.targetLocation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strategic Recommendations */}
              {analysis.recommendations && analysis.recommendations.length > 0 && (
                <div className="bg-amber-50/80 p-5 rounded-2xl border border-amber-200/80 space-y-3">
                  <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2">
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    高層決策建議與營運升級藍圖
                  </h3>
                  <ul className="space-y-2">
                    {analysis.recommendations.map((rec, idx) => (
                      <li key={idx} className="text-xs text-amber-950 flex items-start gap-2">
                        <span className="bg-amber-200 text-amber-900 font-bold rounded-full w-4 h-4 text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="font-medium">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          ) : null}
        </div>

        {/* Footer */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-400">Powered by Google Gemini 3.6 Flash</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl"
          >
            完成閱覽
          </button>
        </div>
      </div>
    </div>
  );
};
