import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  Calendar, 
  User, 
  Sparkles, 
  AlertTriangle, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  Download,
  FileSpreadsheet,
  Table as TableIcon
} from 'lucide-react';
import { ReportItem } from '../types';

interface ReportDetailModalProps {
  report: ReportItem | null;
  onClose: () => void;
  onSingleAIAnalyze: (report: ReportItem) => void;
}

export const ReportDetailModal: React.FC<ReportDetailModalProps> = ({
  report,
  onClose,
  onSingleAIAnalyze,
}) => {
  const [activeTab, setActiveTab] = useState<'traffic' | 'occupancy' | 'issues'>('occupancy');

  if (!report) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white flex items-start justify-between border-b border-slate-800">
          <div>
            <div className="flex items-center space-x-2 mb-2 flex-wrap gap-y-1">
              <span className="bg-blue-600 text-white text-xs font-bold px-2.5 py-0.5 rounded-md flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5" />
                {report.location}
              </span>
              <span className="bg-indigo-500/20 text-indigo-300 text-xs font-semibold px-2.5 py-0.5 rounded-md border border-indigo-500/30 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {report.month.replace('-', '年')}月
              </span>
              <span className="bg-slate-800 text-slate-300 text-xs px-2.5 py-0.5 rounded-md">
                格式: {report.fileType.toUpperCase()}
              </span>
            </div>
            <h2 className="text-xl font-extrabold text-white">{report.title}</h2>
            <div className="flex items-center space-x-3 text-xs text-slate-400 mt-1">
              <span>店長/負責人: <strong className="text-slate-200">{report.manager}</strong></span>
              <span>•</span>
              <span>上傳建立時間: {report.uploadDate}</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onSingleAIAnalyze(report)}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-md flex items-center space-x-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
              <span>AI 獨立分析此檔</span>
            </button>
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* AI Summary Banner */}
        {report.aiSummary && (
          <div className="bg-indigo-50/80 px-6 py-3 border-b border-indigo-100 flex items-start space-x-3 text-xs text-indigo-950">
            <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-indigo-900 font-bold block mb-0.5">Gemini AI 本檔速覽總結:</strong>
              <p className="leading-relaxed text-slate-700">{report.aiSummary}</p>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="bg-slate-100 px-6 pt-3 border-b border-slate-200 flex space-x-2">
          <button
            onClick={() => setActiveTab('occupancy')}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x ${
              activeTab === 'occupancy'
                ? 'bg-white border-slate-200 text-blue-600 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            2. 出租與業績數據 (Occupancy)
          </button>
          <button
            onClick={() => setActiveTab('traffic')}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x ${
              activeTab === 'traffic'
                ? 'bg-white border-slate-200 text-blue-600 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            1. 來客與轉換流量 (Traffic Activity)
          </button>
          <button
            onClick={() => setActiveTab('issues')}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x ${
              activeTab === 'issues'
                ? 'bg-white border-slate-200 text-blue-600 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            3. 各店回報事務與討論 ({report.issues.length})
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* OCCUPANCY TAB */}
          {activeTab === 'occupancy' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <TableIcon className="w-4 h-4 text-blue-600" />
                分店出租率與業績明細表
              </h3>

              <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-2xs">
                <table className="w-full text-xs text-left text-slate-700">
                  <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-[11px] border-b border-slate-200">
                    <tr>
                      <th className="p-3">分店名稱</th>
                      <th className="p-3">統計期間</th>
                      <th className="p-3">出租率 (%)</th>
                      <th className="p-3">本月業績 (NT$)</th>
                      <th className="p-3">業績目標達成率</th>
                      <th className="p-3">去年同期成長率</th>
                      <th className="p-3">新租/退租筆數</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {report.occupancyMetrics.length > 0 ? (
                      report.occupancyMetrics.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 font-bold text-slate-900">{row.storeName}</td>
                          <td className="p-3 text-slate-500">{row.period}</td>
                          <td className="p-3 font-extrabold text-blue-600">{row.occupancyRate}%</td>
                          <td className="p-3 font-mono font-bold text-slate-800">
                            NT$ {row.netSales ? row.netSales.toLocaleString() : '0'}
                          </td>
                          <td className="p-3 font-semibold">
                            <span className={`px-2 py-0.5 rounded-full ${
                              (row.targetRate || 0) >= 100 
                                ? 'bg-emerald-100 text-emerald-800 font-bold' 
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {row.targetRate}%
                            </span>
                          </td>
                          <td className="p-3 font-semibold">
                            <span className={(row.yoyGrowth || 0) >= 0 ? 'text-emerald-600' : 'text-red-500'}>
                              {(row.yoyGrowth || 0) >= 0 ? `+${row.yoyGrowth}%` : `${row.yoyGrowth}%`}
                            </span>
                          </td>
                          <td className="p-3 text-slate-600">
                            +{row.rentalsCount || 0} / -{row.cancellationsCount || 0}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="p-4 text-center text-slate-400 italic">
                          暫無此項目的數據表
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TRAFFIC TAB */}
          {activeTab === 'traffic' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                來客諮詢、轉換與入退倉材積統計
              </h3>

              <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-2xs">
                <table className="w-full text-xs text-left text-slate-700">
                  <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-[11px] border-b border-slate-200">
                    <tr>
                      <th className="p-3">分店</th>
                      <th className="p-3">線上詢問/已連絡</th>
                      <th className="p-3">轉訪率 (%)</th>
                      <th className="p-3">預約/實際參觀</th>
                      <th className="p-3">新入倉筆數/材積</th>
                      <th className="p-3">退倉筆數/材積</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {report.trafficMetrics.length > 0 ? (
                      report.trafficMetrics.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 font-bold text-slate-900">{row.storeName}</td>
                          <td className="p-3 text-slate-700">{row.onlineInquiries || 0} / {row.onlineContacts || 0}</td>
                          <td className="p-3 font-bold text-indigo-600">{row.conversionRate || 0}%</td>
                          <td className="p-3 text-slate-700">{row.appointments || 0} / {row.visits || 0}</td>
                          <td className="p-3 font-semibold text-emerald-700">
                            {row.newSales || 0} 筆 ({row.soldVolume || 0} cubft)
                          </td>
                          <td className="p-3 font-semibold text-amber-700">
                            {row.moveOutCount || 0} 筆 ({row.moveOutVolume || 0} cubft)
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="p-4 text-center text-slate-400 italic">
                          暫無流量指標明細數據
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ISSUES TAB */}
          {activeTab === 'issues' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                各店事務討論、修繕設備與改善方案
              </h3>

              <div className="space-y-3">
                {report.issues.length > 0 ? (
                  report.issues.map((issue, idx) => (
                    <div key={idx} className="bg-slate-50 rounded-xl p-4 border border-slate-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="bg-slate-800 text-white font-bold text-[11px] px-2.5 py-0.5 rounded">
                            {issue.store}
                          </span>
                          <span className="bg-blue-100 text-blue-800 font-semibold text-[11px] px-2 py-0.5 rounded">
                            {issue.category}
                          </span>
                        </div>

                        <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                          issue.status === '已完成' 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}>
                          {issue.status}
                        </span>
                      </div>

                      <p className="text-xs text-slate-800 font-medium leading-relaxed">
                        {issue.description}
                      </p>

                      {issue.actionItem && (
                        <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-xs text-indigo-900 mt-2">
                          <strong className="text-indigo-700 font-bold block">💡 改善行動方案：</strong>
                          <p className="mt-0.5">{issue.actionItem}</p>
                          {issue.assignedTo && (
                            <span className="text-[10px] text-slate-400 block mt-1">負責人: {issue.assignedTo}</span>
                          )}
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400 italic py-4 text-center bg-slate-50 rounded-xl">
                    本期無特殊登錄問題或討論
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-400">系統 ID: {report.id}</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl"
          >
            關閉檢視
          </button>
        </div>
      </div>
    </div>
  );
};
