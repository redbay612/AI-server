import React from 'react';
import { Building2, Calendar, Eye, ArrowRight } from 'lucide-react';
import { ReportItem } from '../types';

interface TableViewProps {
  reports: ReportItem[];
  onSelectReport: (report: ReportItem) => void;
}

export const TableView: React.FC<TableViewProps> = ({ reports, onSelectReport }) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
      <div className="p-4 bg-slate-900 text-white font-bold text-sm flex items-center justify-between">
        <span>全系統會議報告明細數據總表 ({reports.length} 筆)</span>
        <span className="text-xs text-slate-400 font-normal">包含流量、出租率與待辦紀錄</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[11px] border-b border-slate-200">
            <tr>
              <th className="p-3">據點地點</th>
              <th className="p-3">月份</th>
              <th className="p-3">報告名稱</th>
              <th className="p-3">負責店長</th>
              <th className="p-3">總業績 (NT$)</th>
              <th className="p-3">平均出租率</th>
              <th className="p-3">待處理店務問題</th>
              <th className="p-3">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {reports.map((rep) => {
              const totalSales = rep.occupancyMetrics.reduce((sum, item) => sum + (item.netSales || 0), 0);
              const avgOcc = rep.occupancyMetrics.length > 0
                ? (rep.occupancyMetrics.reduce((sum, item) => sum + (item.occupancyRate || 0), 0) / rep.occupancyMetrics.length).toFixed(1)
                : 'N/A';
              const pendingCount = rep.issues.filter((i) => i.status !== '已完成').length;

              return (
                <tr key={rep.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-bold text-blue-600">📍 {rep.location}</td>
                  <td className="p-3 font-semibold text-slate-800">{rep.month}</td>
                  <td className="p-3 font-bold text-slate-900">{rep.title}</td>
                  <td className="p-3 text-slate-600">{rep.manager}</td>
                  <td className="p-3 font-mono font-bold text-slate-800">
                    NT$ {totalSales ? totalSales.toLocaleString() : 0}
                  </td>
                  <td className="p-3 font-extrabold text-blue-600">{avgOcc}%</td>
                  <td className="p-3">
                    {pendingCount > 0 ? (
                      <span className="bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full text-[10px]">
                        {pendingCount} 項處理中
                      </span>
                    ) : (
                      <span className="text-emerald-600 font-semibold text-[11px]">全數完成</span>
                    )}
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => onSelectReport(rep)}
                      className="bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700 font-semibold px-2.5 py-1 rounded-lg text-[11px] transition-colors flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" />
                      <span>查看詳細</span>
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
