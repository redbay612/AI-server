import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileSpreadsheet, 
  FileText, 
  Copy, 
  Check, 
  Printer, 
  Loader2, 
  Sparkles,
  FileCode
} from 'lucide-react';
import * as XLSX from 'xlsx';
import ReactMarkdown from 'react-markdown';
import { ReportItem } from '../types';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reports: ReportItem[];
  filterInfo: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  reports,
  filterInfo,
}) => {
  const [activeTab, setActiveTab] = useState<'excel' | 'doc' | 'html' | 'json'>('excel');
  const [generatedDoc, setGeneratedDoc] = useState<string>('');
  const [isGeneratingDoc, setIsGeneratingDoc] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  // 1. One-click Excel export
  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: Occupancy & Sales Metrics
    const occupancyData: any[] = [];
    reports.forEach((rep) => {
      rep.occupancyMetrics.forEach((m) => {
        occupancyData.push({
          歸屬據點: rep.location,
          歸屬月份: rep.month,
          店長: rep.manager,
          分店名稱: m.storeName,
          統計期間: m.period,
          '出租率 (%)': m.occupancyRate,
          '本月業績 (NT$)': m.netSales,
          '目標達成率 (%)': m.targetRate,
          '去年同期成長 (%)': m.yoyGrowth,
        });
      });
    });
    const wsOccupancy = XLSX.utils.json_to_sheet(occupancyData);
    XLSX.utils.book_append_sheet(wb, wsOccupancy, '出租率與業績數據');

    // Sheet 2: Traffic Metrics
    const trafficData: any[] = [];
    reports.forEach((rep) => {
      rep.trafficMetrics.forEach((t) => {
        trafficData.push({
          歸屬據點: rep.location,
          歸屬月份: rep.month,
          店長: rep.manager,
          分店名稱: t.storeName,
          統計期間: t.period,
          '線上詢問': t.onlineInquiries || 0,
          '線上連絡': t.onlineContacts || 0,
          '轉訪率 (%)': t.conversionRate || 0,
          '預約參觀': t.appointments || 0,
          '實際參觀': t.visits || 0,
          '新入倉筆數': t.newSales || 0,
          '新入倉材積': t.soldVolume || 0,
          '退倉筆數': t.moveOutCount || 0,
          '退倉材積': t.moveOutVolume || 0,
        });
      });
    });
    const wsTraffic = XLSX.utils.json_to_sheet(trafficData);
    XLSX.utils.book_append_sheet(wb, wsTraffic, '來客流量與轉換指標');

    // Sheet 3: Store Issues & Discussions
    const issueData: any[] = [];
    reports.forEach((rep) => {
      rep.issues.forEach((iss) => {
        issueData.push({
          歸屬據點: rep.location,
          歸屬月份: rep.month,
          分類: iss.category,
          分店: iss.store,
          問題描述: iss.description,
          狀態: iss.status,
          改善方案: iss.actionItem || '',
          負責人: iss.assignedTo || '',
        });
      });
    });
    const wsIssues = XLSX.utils.json_to_sheet(issueData);
    XLSX.utils.book_append_sheet(wb, wsIssues, '各店事務與討論');

    // Save File
    const fileName = `會議報告數據彙整表_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  // 2. Generate Executive Markdown Doc using Gemini
  const handleGenerateDoc = async () => {
    setIsGeneratingDoc(true);
    try {
      const response = await fetch('/api/generate-export-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reports,
          filterInfo,
        }),
      });

      const data = await response.json();
      if (data.success && data.markdown) {
        setGeneratedDoc(data.markdown);
      } else {
        throw new Error(data.error || '生成失敗');
      }
    } catch (err: any) {
      console.error('Doc Gen error:', err);
      alert('生成文字報告時發生錯誤: ' + err.message);
    } fontFinally: {
      setIsGeneratingDoc(false);
    }
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(generatedDoc);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadMarkdown = () => {
    const blob = new Blob([generatedDoc], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `高階開會報告彙整總結_${new Date().toISOString().slice(0, 10)}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 3. Export Standalone Single-File Web HTML Preview
  const handleExportHTML = () => {
    const tableRows = reports.map((r) => {
      const totalSales = r.occupancyMetrics.reduce((sum, item) => sum + (item.netSales || 0), 0);
      const avgOcc = r.occupancyMetrics.length > 0
        ? (r.occupancyMetrics.reduce((sum, item) => sum + (item.occupancyRate || 0), 0) / r.occupancyMetrics.length).toFixed(1)
        : 'N/A';
      return `
        <tr style="border-bottom: 1px solid #f1f5f9;">
          <td style="padding: 12px; font-weight: bold; color: #2563eb;">📍 ${r.location}</td>
          <td style="padding: 12px; color: #334155;">${r.month}</td>
          <td style="padding: 12px; font-weight: bold; color: #0f172a;">${r.title}</td>
          <td style="padding: 12px; color: #475569;">${r.manager}</td>
          <td style="padding: 12px; font-weight: bold; color: #059669;">NT$ ${totalSales.toLocaleString()}</td>
          <td style="padding: 12px; font-weight: bold; color: #2563eb;">${avgOcc}%</td>
          <td style="padding: 12px; color: #64748b;">${r.issues.length} 項紀錄</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>會議報告彙整分析系統 - 網頁版獨立預覽</title>
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background-color: #f8fafc; color: #0f172a; margin: 0; padding: 24px; }
  </style>
</head>
<body>
  <div style="max-width: 1200px; margin: 0 auto;">
    <header style="background: white; padding: 20px 24px; border-radius: 16px; border: 1px solid #e2e8f0; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; shadow: 0 1px 2px rgba(0,0,0,0.05);">
      <div>
        <h1 style="font-size: 20px; font-weight: 800; color: #0f172a; margin: 0;">會議報告彙整分析系統 <span style="color: #2563eb;">Meeting Insights</span></h1>
        <p style="font-size: 12px; color: #64748b; margin-top: 4px;">離線單檔網頁預覽包 • 生成時間：${new Date().toLocaleString()}</p>
      </div>
      <span style="background: #eff6ff; color: #2563eb; font-size: 11px; font-weight: bold; padding: 6px 12px; border-radius: 20px; border: 1px solid #dbeafe;">
        收錄 ${reports.length} 份報告
      </span>
    </header>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-bottom: 24px;">
      <div style="background: white; padding: 20px; border-radius: 16px; border: 1px solid #e2e8f0;">
        <span style="font-size: 12px; color: #64748b; font-weight: bold;">匯總報告筆數</span>
        <div style="font-size: 28px; font-weight: 900; color: #0f172a; margin-top: 4px;">${reports.length} 份</div>
      </div>
      <div style="background: #0f172a; color: white; padding: 20px; border-radius: 16px;">
        <span style="font-size: 12px; color: #94a3b8; font-weight: bold;">篩選範圍與條件</span>
        <div style="font-size: 14px; font-weight: bold; color: #38bdf8; margin-top: 8px;">${filterInfo}</div>
      </div>
    </div>

    <div style="background: white; border-radius: 16px; border: 1px solid #e2e8f0; padding: 20px; overflow-x: auto;">
      <h2 style="font-size: 15px; font-weight: bold; margin-bottom: 16px; color: #0f172a;">會議報告列表明細</h2>
      <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 13px;">
        <thead>
          <tr style="background: #f1f5f9; color: #475569; font-weight: bold;">
            <th style="padding: 12px;">據點</th>
            <th style="padding: 12px;">月份</th>
            <th style="padding: 12px;">報告名稱</th>
            <th style="padding: 12px;">負責店長</th>
            <th style="padding: 12px;">總業績</th>
            <th style="padding: 12px;">平均出租率</th>
            <th style="padding: 12px;">討論事項</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'index.html');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 4. Export JSON
  const handleExportJSON = () => {
    const blob = new Blob([JSON.stringify(reports, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `會議報告備份_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-900 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-300 rounded-xl border border-emerald-500/30">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">一鍵導出報告數據與 AI 分析結果</h2>
              <p className="text-xs text-slate-300">支援匯出 Excel 試算表、高階文字簡報或 JSON 備份檔</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-slate-100 px-6 pt-3 border-b border-slate-200 flex space-x-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('excel')}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x whitespace-nowrap ${
              activeTab === 'excel'
                ? 'bg-white border-slate-200 text-emerald-700 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            📊 匯出 Excel / CSV 表格
          </button>
          <button
            onClick={() => {
              setActiveTab('doc');
              if (!generatedDoc) handleGenerateDoc();
            }}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x whitespace-nowrap ${
              activeTab === 'doc'
                ? 'bg-white border-slate-200 text-emerald-700 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            ✨ 匯出高階 AI 總結簡報 (Word/MD)
          </button>
          <button
            onClick={() => setActiveTab('html')}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x whitespace-nowrap ${
              activeTab === 'html'
                ? 'bg-white border-slate-200 text-blue-700 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            🌐 下載獨立網頁版 (HTML Preview)
          </button>
          <button
            onClick={() => setActiveTab('json')}
            className={`py-2 px-4 text-xs font-bold rounded-t-xl transition-all border-t border-x whitespace-nowrap ${
              activeTab === 'json'
                ? 'bg-white border-slate-200 text-emerald-700 shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            💾 匯出 JSON 備份檔
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* EXCEL TAB */}
          {activeTab === 'excel' && (
            <div className="space-y-4 text-center py-6">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <FileSpreadsheet className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">一鍵產生跨據點多頁籤 Excel 報表</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  包含 <strong className="text-slate-700">出租率與業績數據</strong>、<strong className="text-slate-700">來客流量與轉換率</strong>、以及 <strong className="text-slate-700">各店修繕與討論事項</strong> 3個獨立工作表。
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 text-xs text-slate-600 max-w-md mx-auto text-left space-y-1">
                <p>• 匯出報告數量：<strong>{reports.length} 份會議報告</strong></p>
                <p>• 篩選條件：{filterInfo}</p>
                <p>• 檔案格式：<strong>Microsoft Excel (.xlsx)</strong></p>
              </div>

              <button
                onClick={handleExportExcel}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 mx-auto"
              >
                <Download className="w-4 h-4" />
                <span>立即下載完整 Excel 表格 (.xlsx)</span>
              </button>
            </div>
          )}

          {/* AI DOC TAB */}
          {activeTab === 'doc' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">AI 高階決策簡報報告內容：</span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleGenerateDoc}
                    disabled={isGeneratingDoc}
                    className="p-1.5 text-xs text-indigo-600 hover:bg-indigo-50 rounded-lg flex items-center gap-1 font-semibold"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>重新產生</span>
                  </button>
                  <button
                    onClick={handleCopyText}
                    disabled={!generatedDoc}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? '已複製！' : '複製內文'}</span>
                  </button>
                  <button
                    onClick={handleDownloadMarkdown}
                    disabled={!generatedDoc}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>下載 .md / Word</span>
                  </button>
                </div>
              </div>

              {isGeneratingDoc ? (
                <div className="py-16 text-center space-y-3">
                  <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
                  <p className="text-xs font-bold text-slate-700">Gemini 正在為您排版與生成高階會議簡報報告...</p>
                </div>
              ) : generatedDoc ? (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-800 space-y-2 max-h-96 overflow-y-auto">
                  <div className="markdown-body prose prose-xs max-w-none">
                    <ReactMarkdown>{generatedDoc}</ReactMarkdown>
                  </div>
                </div>
              ) : null}
            </div>
          )}

          {/* HTML TAB */}
          {activeTab === 'html' && (
            <div className="space-y-4 text-center py-6">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">下載單檔離線網頁版 (.html) 預覽報告</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  包含當前 <strong className="text-slate-700">{reports.length} 份報告數據</strong> 與全套樣式表。點擊下載後可在任何電腦、手機或平板的瀏覽器直接開啟觀看，無需安裝任何軟體。
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 text-xs text-slate-600 max-w-md mx-auto text-left space-y-1">
                <p>• 檔案格式：<strong>HTML 獨立網頁檔 (.html)</strong></p>
                <p>• 內容：全區統計面板、業績與出租率明細表格</p>
                <p>• 特色：零依賴，可離線雙擊開啟預覽與列印</p>
              </div>

              <button
                onClick={handleExportHTML}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 mx-auto"
              >
                <Download className="w-4 h-4" />
                <span>立即下載 index.html 網頁檔</span>
              </button>
            </div>
          )}

          {/* JSON TAB */}
          {activeTab === 'json' && (
            <div className="space-y-4 text-center py-6">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                <FileCode className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">匯出完整 JSON 結構化資料庫備份</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  適合用於系統整合、系統轉移或資料庫備份。
                </p>
              </div>

              <button
                onClick={handleExportJSON}
                className="px-6 py-3 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 mx-auto"
              >
                <Download className="w-4 h-4" />
                <span>下載 JSON 備份檔</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs"
          >
            關閉視窗
          </button>
        </div>
      </div>
    </div>
  );
};
