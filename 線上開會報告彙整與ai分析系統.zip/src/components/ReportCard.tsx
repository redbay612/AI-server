import React from 'react';
import { 
  Building2, 
  Calendar, 
  User, 
  FileSpreadsheet, 
  FileText, 
  Image as ImageIcon, 
  AlertTriangle, 
  TrendingUp, 
  ArrowRight, 
  Trash2, 
  Sparkles,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { ReportItem } from '../types';

interface ReportCardProps {
  report: ReportItem;
  onSelect: (report: ReportItem) => void;
  onDelete: (id: string) => void;
  onSingleAIAnalyze: (report: ReportItem) => void;
}

export const ReportCard: React.FC<ReportCardProps> = ({
  report,
  onSelect,
  onDelete,
  onSingleAIAnalyze,
}) => {
  // Calculate total net sales and total occupancy
  const totalSales = report.occupancyMetrics.reduce((acc, m) => acc + (m.netSales || 0), 0);
  const avgOccupancy = report.occupancyMetrics.length > 0
    ? (report.occupancyMetrics.reduce((acc, m) => acc + (m.occupancyRate || 0), 0) / report.occupancyMetrics.length).toFixed(1)
    : 'N/A';
  
  const avgTargetRate = report.occupancyMetrics.length > 0
    ? (report.occupancyMetrics.reduce((acc, m) => acc + (m.targetRate || 0), 0) / report.occupancyMetrics.length).toFixed(1)
    : null;

  const pendingIssuesCount = report.issues.filter(i => i.status !== '已完成').length;

  const getFileIcon = () => {
    switch (report.fileType) {
      case 'excel':
        return <FileSpreadsheet className="w-4 h-4 text-emerald-600" />;
      case 'image':
        return <ImageIcon className="w-4 h-4 text-purple-600" />;
      case 'pdf':
      case 'word':
        return <FileText className="w-4 h-4 text-blue-600" />;
      default:
        return <FileText className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden">
      {/* Card Header */}
      <div className="p-5 border-b border-slate-100 bg-gradient-to-br from-slate-50/50 to-white">
        <div className="flex items-start justify-between gap-3 mb-2">
          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
            <span className="bg-blue-600 text-white font-bold text-xs px-2.5 py-0.5 rounded-lg flex items-center gap-1 shadow-sm">
              <Building2 className="w-3 h-3" />
              {report.location}
            </span>
            <span className="bg-indigo-50 text-indigo-700 font-semibold text-xs px-2.5 py-0.5 rounded-lg border border-indigo-200/60 flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {report.month.replace('-', '年')}月
            </span>
            <span className="bg-slate-100 text-slate-600 text-xs px-2 py-0.5 rounded-md flex items-center gap-1 font-medium">
              {getFileIcon()}
              <span className="uppercase text-[11px] font-semibold">{report.fileType}</span>
            </span>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete(report.id);
            }}
            title="刪除這份報告"
            className="text-slate-300 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        <h3 
          onClick={() => onSelect(report)}
          className="text-base font-bold text-slate-800 hover:text-blue-600 cursor-pointer transition-colors line-clamp-1 mb-1"
        >
          {report.title}
        </h3>

        <div className="flex items-center space-x-3 text-xs text-slate-400">
          <span className="flex items-center space-x-1">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span>店長：<strong className="text-slate-600">{report.manager || '未指定'}</strong></span>
          </span>
          <span>•</span>
          <span>上傳日期：{report.uploadDate}</span>
        </div>
      </div>

      {/* KPI Metrics Highlight */}
      <div className="px-5 py-3.5 bg-slate-50/60 grid grid-cols-2 gap-3 border-b border-slate-100 text-xs">
        <div className="bg-white p-2.5 rounded-xl border border-slate-100 shadow-2xs">
          <span className="text-slate-400 text-[11px] font-medium block">總業績 (本月)</span>
          <div className="text-sm font-extrabold text-slate-800 mt-0.5 flex items-baseline justify-between">
            <span>NT$ {totalSales > 0 ? totalSales.toLocaleString() : '—'}</span>
            {avgTargetRate && (
              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                Number(avgTargetRate) >= 100 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
              }`}>
                {avgTargetRate}% 達標
              </span>
            )}
          </div>
        </div>

        <div className="bg-white p-2.5 rounded-xl border border-slate-100 shadow-2xs">
          <span className="text-slate-400 text-[11px] font-medium block">平均出租率</span>
          <div className="text-sm font-extrabold text-slate-800 mt-0.5 flex items-center justify-between">
            <span className="text-blue-600 font-black">{avgOccupancy}%</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
          </div>
        </div>
      </div>

      {/* Key Discussion & Issues preview */}
      <div className="p-5 flex-1 space-y-3">
        {report.issues.length > 0 ? (
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                店務回報與待辦 ({report.issues.length}項)
              </span>
              {pendingIssuesCount > 0 && (
                <span className="bg-amber-50 text-amber-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-200">
                  {pendingIssuesCount} 項處理中
                </span>
              )}
            </div>

            <ul className="space-y-1.5">
              {report.issues.slice(0, 2).map((issue, idx) => (
                <li key={idx} className="text-xs bg-slate-50 p-2 rounded-lg border border-slate-100/80 flex items-start justify-between gap-2">
                  <div className="line-clamp-2 text-slate-600">
                    <strong className="text-slate-800 font-semibold mr-1">[{issue.category}]</strong>
                    {issue.description}
                  </div>
                  <span className={`shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    issue.status === '已完成' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {issue.status}
                  </span>
                </li>
              ))}
              {report.issues.length > 2 && (
                <p className="text-[11px] text-blue-600 font-medium pt-0.5 cursor-pointer hover:underline" onClick={() => onSelect(report)}>
                  + 還有 {report.issues.length - 2} 項店務討論與回報內容...
                </p>
              )}
            </ul>
          </div>
        ) : (
          <div className="text-xs text-slate-400 py-3 text-center italic bg-slate-50/50 rounded-lg">
            無重大異常問題回報
          </div>
        )}

        {/* AI Summary snippet */}
        {report.aiSummary && (
          <div className="bg-indigo-50/50 p-2.5 rounded-xl border border-indigo-100/80 text-xs text-indigo-900">
            <span className="font-bold flex items-center gap-1 text-indigo-700 text-[11px] mb-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              AI 摘要速覽
            </span>
            <p className="line-clamp-2 text-slate-700 text-[11px] leading-relaxed">
              {report.aiSummary}
            </p>
          </div>
        )}
      </div>

      {/* Card Footer Actions */}
      <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
        <button
          onClick={() => onSingleAIAnalyze(report)}
          className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 hover:bg-indigo-50 px-2.5 py-1.5 rounded-lg transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>單份 AI 解讀</span>
        </button>

        <button
          onClick={() => onSelect(report)}
          className="bg-slate-800 hover:bg-slate-900 text-white font-semibold px-3 py-1.5 rounded-lg flex items-center space-x-1 transition-all shadow-2xs"
        >
          <span>查看完整數據</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
