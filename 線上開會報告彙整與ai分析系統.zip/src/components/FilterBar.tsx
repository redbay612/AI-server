import React from 'react';
import { 
  MapPin, 
  Calendar, 
  Search, 
  LayoutGrid, 
  Table2, 
  BarChart, 
  X,
  Filter
} from 'lucide-react';
import { FilterState } from '../types';

interface FilterBarProps {
  locations: string[];
  months: string[];
  categories: string[];
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  viewMode: 'grid' | 'matrix' | 'table';
  onViewModeChange: (mode: 'grid' | 'matrix' | 'table') => void;
  totalFiltered: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  locations,
  months,
  categories,
  filters,
  onFilterChange,
  viewMode,
  onViewModeChange,
  totalFiltered,
}) => {
  const hasActiveFilters = 
    filters.selectedLocation !== 'ALL' || 
    filters.selectedMonth !== 'ALL' || 
    filters.searchQuery.trim() !== '' ||
    !!filters.selectedCategory;

  const handleClearFilters = () => {
    onFilterChange({
      selectedLocation: 'ALL',
      selectedMonth: 'ALL',
      searchQuery: '',
      selectedCategory: undefined,
    });
  };

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/80 mb-6 space-y-3">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Filter selectors */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-1.5 text-xs text-slate-500 font-semibold uppercase tracking-wider pr-1">
            <Filter className="w-4 h-4 text-blue-600" />
            <span>分類篩選:</span>
          </div>

          {/* Location Select (地點分類) */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
              <MapPin className="w-4 h-4 text-blue-500" />
            </div>
            <select
              value={filters.selectedLocation}
              onChange={(e) => onFilterChange({ ...filters, selectedLocation: e.target.value })}
              className="pl-8 pr-8 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer appearance-none transition-colors"
            >
              <option value="ALL">📍 所有地點 / 據點</option>
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          {/* Month Select (月份分類) */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
              <Calendar className="w-4 h-4 text-indigo-500" />
            </div>
            <select
              value={filters.selectedMonth}
              onChange={(e) => onFilterChange({ ...filters, selectedMonth: e.target.value })}
              className="pl-8 pr-8 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer appearance-none transition-colors"
            >
              <option value="ALL">📅 所有月份</option>
              {months.map((m) => (
                <option key={m} value={m}>
                  {m.replace('-', '年')}月
                </option>
              ))}
            </select>
          </div>

          {/* Search Input (關鍵字搜尋) */}
          <div className="relative min-w-[200px] flex-1 sm:flex-initial">
            <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="搜尋報告、店長、問題(如漏水,刷卡)..."
              value={filters.searchQuery}
              onChange={(e) => onFilterChange({ ...filters, searchQuery: e.target.value })}
              className="pl-8 pr-8 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-slate-400"
            />
            {filters.searchQuery && (
              <button
                onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
                className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Clear button if active */}
          {hasActiveFilters && (
            <button
              onClick={handleClearFilters}
              className="flex items-center space-x-1 text-xs text-slate-500 hover:text-red-600 px-2 py-1 rounded-lg hover:bg-red-50 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
              <span>清除條件</span>
            </button>
          )}
        </div>

        {/* View mode toggle */}
        <div className="flex items-center justify-between sm:justify-end space-x-2 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-100">
          <span className="text-xs text-slate-400 font-medium mr-2">
            共 <strong className="text-slate-700 font-semibold">{totalFiltered}</strong> 份結果
          </span>

          <div className="bg-slate-100 p-1 rounded-xl flex items-center space-x-1">
            <button
              onClick={() => onViewModeChange('grid')}
              title="圖卡檢視模式"
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === 'grid'
                  ? 'bg-white text-blue-600 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>圖卡卡片</span>
            </button>

            <button
              onClick={() => onViewModeChange('matrix')}
              title="跨據點月份對比矩陣"
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === 'matrix'
                  ? 'bg-white text-blue-600 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart className="w-3.5 h-3.5" />
              <span>跨區對比</span>
            </button>

            <button
              onClick={() => onViewModeChange('table')}
              title="詳細KPI表格"
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === 'table'
                  ? 'bg-white text-blue-600 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Table2 className="w-3.5 h-3.5" />
              <span>KPI數據表</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Category Tags Filter */}
      {categories.length > 0 && (
        <div className="flex items-center space-x-2 pt-1 overflow-x-auto pb-1 text-xs no-scrollbar">
          <span className="text-slate-400 text-xs shrink-0 font-medium">主題標籤:</span>
          <button
            onClick={() => onFilterChange({ ...filters, selectedCategory: undefined })}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium shrink-0 transition-colors ${
              !filters.selectedCategory 
                ? 'bg-blue-100 text-blue-700 font-semibold' 
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            全部議題
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => onFilterChange({ ...filters, selectedCategory: cat })}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium shrink-0 transition-colors ${
                filters.selectedCategory === cat
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
