import React from 'react';
import { 
  Building2, 
  Upload, 
  Sparkles, 
  Download, 
  Bot, 
  FileSpreadsheet, 
  BarChart3,
  RefreshCw
} from 'lucide-react';

interface NavbarProps {
  reportCount: number;
  filteredCount: number;
  onOpenUpload: () => void;
  onOpenAIAnalysis: () => void;
  onOpenExport: () => void;
  onToggleChat: () => void;
  isChatOpen: boolean;
  onResetData: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  reportCount,
  filteredCount,
  onOpenUpload,
  onOpenAIAnalysis,
  onOpenExport,
  onToggleChat,
  isChatOpen,
  onResetData,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md text-slate-800 border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 py-3">
          {/* Logo and Brand Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2.5 rounded-2xl shadow-md text-white flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-extrabold tracking-tight text-slate-800">
                  會議報告彙整分析系統 <span className="text-blue-600 font-black">Meeting Insights</span>
                </h1>
                <span className="bg-blue-50 text-blue-600 text-[10px] px-2.5 py-0.5 rounded-full border border-blue-100 font-bold uppercase tracking-wide">
                  AI Active
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                智慧分類與 AI 深度報告分析 • 多據點與跨月份數據洞察
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <div className="hidden lg:flex items-center space-x-2 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200/80 text-xs text-slate-600 font-medium mr-1">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>載入: <strong className="text-slate-900 font-bold">{reportCount}</strong> 份報告</span>
            </div>

            <button
              onClick={onResetData}
              title="重設為預設範例資料"
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenUpload}
              className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-500/10 active:scale-95"
            >
              <Upload className="w-4 h-4" />
              <span>+ 上傳報告</span>
            </button>

            <button
              onClick={onOpenAIAnalysis}
              className="flex items-center space-x-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-purple-300" />
              <span className="hidden sm:inline">AI 核心分析</span>
            </button>

            <button
              onClick={onOpenExport}
              className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">導出報告</span>
            </button>

            <button
              onClick={onToggleChat}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all ${
                isChatOpen 
                  ? 'bg-amber-100 text-amber-900 border-amber-300' 
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Bot className="w-4 h-4 text-amber-500" />
              <span className="hidden md:inline">AI 助手</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
