import React, { useState } from 'react';
import { 
  X, 
  Upload, 
  FileSpreadsheet, 
  FileText, 
  Image as ImageIcon, 
  Sparkles, 
  Loader2, 
  CheckCircle, 
  AlertCircle,
  Building2,
  Calendar,
  FileCode
} from 'lucide-react';
import { ReportItem } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddReport: (report: ReportItem) => void;
  locations: string[];
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onAddReport,
  locations,
}) => {
  const [activeTab, setActiveTab] = useState<'file' | 'manual'>('file');
  const [selectedLocation, setSelectedLocation] = useState<string>('松山據點');
  const [customLocation, setCustomLocation] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-08');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string>('');
  const [manualText, setManualText] = useState<string>('');
  const [isParsing, setIsParsing] = useState<boolean>(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [previewParsedData, setPreviewParsedData] = useState<Partial<ReportItem> | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setParseError(null);
      const reader = new FileReader();
      reader.onload = (event) => {
        setFileBase64(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleParseReport = async () => {
    setIsParsing(true);
    setParseError(null);

    const targetLocation = customLocation.trim() || selectedLocation;
    const fileExtension = selectedFile?.name.split('.').pop()?.toLowerCase();
    let fileType: ReportItem['fileType'] = 'excel';
    if (fileExtension === 'pdf') fileType = 'pdf';
    else if (['png', 'jpg', 'jpeg', 'webp'].includes(fileExtension || '')) fileType = 'image';
    else if (['doc', 'docx'].includes(fileExtension || '')) fileType = 'word';
    else if (activeTab === 'manual') fileType = 'manual';

    try {
      const response = await fetch('/api/parse-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: selectedFile?.name || '會議報告',
          fileType,
          fileBase64,
          textContent: manualText,
          locationHint: targetLocation,
          monthHint: selectedMonth,
        }),
      });

      const result = await response.json();

      if (result.success && result.data) {
        const parsed = result.data;
        const newReport: ReportItem = {
          id: `rep-${Date.now()}`,
          title: parsed.title || `${targetLocation} ${selectedMonth.replace('-', '年')}月會議報告`,
          location: parsed.location || targetLocation,
          month: parsed.month || selectedMonth,
          manager: parsed.manager || '門市主管',
          uploadDate: new Date().toISOString().slice(0, 16).replace('T', ' '),
          fileName: selectedFile?.name || '貼上之報告內容',
          fileType,
          fileDataUrl: fileBase64 || undefined,
          rawText: manualText || undefined,
          trafficMetrics: parsed.trafficMetrics || [],
          occupancyMetrics: parsed.occupancyMetrics || [],
          issues: parsed.issues || [],
          aiSummary: parsed.aiSummary || '自動擷取摘要',
          tags: parsed.tags || [targetLocation, selectedMonth],
        };

        setPreviewParsedData(newReport);
      } else {
        throw new Error(result.error || '解析失敗');
      }
    } catch (err: any) {
      console.error('Parse error:', err);
      setParseError(err.message || 'Gemini AI 解析失敗，請檢查檔案格式或網路連線');
    } finally {
      setIsParsing(false);
    }
  };

  const handleConfirmSave = () => {
    if (previewParsedData) {
      onAddReport(previewParsedData as ReportItem);
      onClose();
      // reset form
      setSelectedFile(null);
      setFileBase64('');
      setManualText('');
      setPreviewParsedData(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-indigo-500/20 rounded-xl border border-indigo-500/30">
              <Upload className="w-5 h-5 text-indigo-300" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">上傳會議報告與地點分類</h2>
              <p className="text-xs text-slate-300">支援 Excel、PDF、照片截圖或手動貼上，並由 Gemini 智慧解析表格</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          {/* Classification Settings (地點 & 月份) */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-1">
                <Building2 className="w-4 h-4 text-blue-600" />
                歸屬據點 / 地點分類 *
              </label>
              <div className="space-y-2">
                <select
                  value={selectedLocation}
                  onChange={(e) => {
                    setSelectedLocation(e.target.value);
                    if (e.target.value !== 'OTHER') setCustomLocation('');
                  }}
                  className="w-full p-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
                >
                  {locations.map((loc) => (
                    <option key={loc} value={loc}>
                      📍 {loc}
                    </option>
                  ))}
                  <option value="OTHER">+ 自訂新據點/地點</option>
                </select>

                {selectedLocation === 'OTHER' && (
                  <input
                    type="text"
                    placeholder="請輸入新據點名稱 (例如: 板橋據點)"
                    value={customLocation}
                    onChange={(e) => setCustomLocation(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl text-xs"
                  />
                )}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-1">
                <Calendar className="w-4 h-4 text-indigo-600" />
                歸屬月份分類 *
              </label>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Mode Switch Tab */}
          <div className="flex border-b border-slate-200">
            <button
              onClick={() => setActiveTab('file')}
              className={`pb-2 px-4 text-xs font-bold transition-all border-b-2 ${
                activeTab === 'file'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-400 hover:text-slate-700'
              }`}
            >
              檔案上傳 (Excel / PDF / 照片)
            </button>
            <button
              onClick={() => setActiveTab('manual')}
              className={`pb-2 px-4 text-xs font-bold transition-all border-b-2 ${
                activeTab === 'manual'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-400 hover:text-slate-700'
              }`}
            >
              貼上逐字或文字報告
            </button>
          </div>

          {/* Tab 1: File Upload */}
          {activeTab === 'file' && (
            <div className="space-y-3">
              <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl p-6 text-center bg-slate-50/50 hover:bg-blue-50/30 transition-all cursor-pointer relative">
                <input
                  type="file"
                  accept=".xlsx,.xls,.pdf,.doc,.docx,.png,.jpg,.jpeg"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="flex flex-col items-center justify-center space-y-2">
                  <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
                    <FileSpreadsheet className="w-7 h-7" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-700">點擊上傳或拖曳會議報告至此區域</p>
                    <p className="text-[11px] text-slate-400 mt-1">支援 .xlsx, .xls, .pdf, .docx, 照片截圖 (PNG/JPG)</p>
                  </div>
                </div>
              </div>

              {selectedFile && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-center justify-between text-xs text-blue-900">
                  <div className="flex items-center space-x-2">
                    <FileCode className="w-4 h-4 text-blue-600" />
                    <span className="font-semibold">{selectedFile.name}</span>
                    <span className="text-slate-400">({(selectedFile.size / 1024).toFixed(1)} KB)</span>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedFile(null);
                      setFileBase64('');
                    }}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Manual Paste */}
          {activeTab === 'manual' && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 block">請直接貼上會議紀錄、討論事項或KPI文字數據：</label>
              <textarea
                rows={6}
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                placeholder="例如：松山據點8月份總業績 $2,751,444，三店走道有漏水狀況需維修，信用卡刷卡分期中國信託10筆..."
                className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-800 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          )}

          {/* Error notice */}
          {parseError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{parseError}</span>
            </div>
          )}

          {/* Preview Parsed Data Result */}
          {previewParsedData && (
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Gemini AI 成功解析報告！確認預覽如下：</span>
              </div>

              <div className="bg-white p-3 rounded-lg border border-emerald-100 text-xs space-y-1.5">
                <p><strong>標題：</strong> {previewParsedData.title}</p>
                <p><strong>地點：</strong> <span className="bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold">{previewParsedData.location}</span></p>
                <p><strong>月份：</strong> <span className="bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded font-bold">{previewParsedData.month}</span></p>
                <p><strong>擷取店務討論數：</strong> {previewParsedData.issues?.length || 0} 項</p>
                <p><strong>AI 摘要：</strong> {previewParsedData.aiSummary}</p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-xl"
          >
            取消
          </button>

          {!previewParsedData ? (
            <button
              onClick={handleParseReport}
              disabled={isParsing || (activeTab === 'file' && !selectedFile) || (activeTab === 'manual' && !manualText.trim())}
              className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md flex items-center space-x-2 transition-all"
            >
              {isParsing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Gemini AI 正在解析報告中...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>開始 AI 自動分類與解析</span>
                </>
              )}
            </button>
          ) : (
            <button
              onClick={handleConfirmSave}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center space-x-1.5"
            >
              <CheckCircle className="w-4 h-4" />
              <span>確認加入資料庫</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
