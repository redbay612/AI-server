import React from 'react';
import { Building2, Calendar, TrendingUp, AlertTriangle, ArrowUpRight } from 'lucide-react';
import { ReportItem } from '../types';

interface MatrixViewProps {
  reports: ReportItem[];
  locations: string[];
  months: string[];
  onSelectReport: (report: ReportItem) => void;
}

export const MatrixView: React.FC<MatrixViewProps> = ({
  reports,
  locations,
  months,
  onSelectReport,
}) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-600" />
            跨地點與跨月份對比矩陣 (Location x Month Matrix)
          </h2>
          <p className="text-xs text-slate-400">方便高層一次性橫向對比各據點在各月份的業績與異常項目</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 text-white font-bold text-[11px]">
              <th className="p-3 border border-slate-800 rounded-tl-xl min-w-[140px]">據點 / 地點</th>
              {months.map((m) => (
                <th key={m} className="p-3 border border-slate-800 text-center min-w-[200px]">
                  {m.replace('-', '年')}月份
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 text-slate-700">
            {locations.map((loc) => (
              <tr key={loc} className="hover:bg-slate-50/80 transition-colors">
                <td className="p-3.5 font-bold text-slate-900 bg-slate-50 border border-slate-200">
                  📍 {loc}
                </td>
                {months.map((m) => {
                  const match = reports.find((r) => r.location === loc && r.month === m);

                  if (!match) {
                    return (
                      <td key={m} className="p-3.5 border border-slate-200 text-center text-slate-300 italic bg-slate-50/30">
                        未上傳報告
                      </td>
                    );
                  }

                  const totalSales = match.occupancyMetrics.reduce((sum, item) => sum + (item.netSales || 0), 0);
                  const avgOcc = match.occupancyMetrics.length > 0
                    ? (match.occupancyMetrics.reduce((sum, item) => sum + (item.occupancyRate || 0), 0) / match.occupancyMetrics.length).toFixed(1)
                    : 'N/A';

                  return (
                    <td key={m} className="p-3 border border-slate-200 bg-white hover:bg-blue-50/40 transition-colors">
                      <div 
                        onClick={() => onSelectReport(match)}
                        className="cursor-pointer group space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-slate-800 group-hover:text-blue-600 transition-colors line-clamp-1">
                            {match.title}
                          </span>
                          <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 transition-colors shrink-0" />
                        </div>

                        <div className="grid grid-cols-2 gap-1 text-[10px] bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                          <div>
                            <span className="text-slate-400 block">業績</span>
                            <strong className="text-slate-800 font-bold">NT$ {totalSales ? (totalSales / 10000).toFixed(1) : 0}萬</strong>
                          </div>
                          <div>
                            <span className="text-slate-400 block">出租率</span>
                            <strong className="text-blue-600 font-extrabold">{avgOcc}%</strong>
                          </div>
                        </div>

                        {match.issues.length > 0 && (
                          <div className="text-[10px] bg-amber-50 text-amber-800 p-1 rounded font-semibold flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                            <span className="line-clamp-1">{match.issues[0].description}</span>
                          </div>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
